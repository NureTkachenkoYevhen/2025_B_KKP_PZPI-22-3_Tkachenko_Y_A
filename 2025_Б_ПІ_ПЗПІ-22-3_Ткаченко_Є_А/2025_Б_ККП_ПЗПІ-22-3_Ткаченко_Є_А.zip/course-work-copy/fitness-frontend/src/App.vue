<template>
  <div>
    <main class="p-4 pb-20"> 
      <router-view />
    </main>
    <NavBar v-if="auth.isAuthenticated" />
  </div>
</template>

<script setup>
import NavBar from './components/NavBar.vue'
import { useAuthStore } from './stores/auth'

const auth = useAuthStore()
</script>
