<template>
  <div class="max-w-4xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-md">

    <!-- Tabs -->
    <div class="flex border-b mb-6">
      <button
        class="px-4 py-2 font-medium text-sm border-b-2 transition"
        :class="{
          'border-blue-600 text-blue-600': activeTab === 'height',
          'border-transparent text-gray-600 hover:text-blue-600': activeTab !== 'height'
        }"
        @click="activeTab = 'height'"
      >
        Height (cm)
      </button>
      <button
        class="ml-4 px-4 py-2 font-medium text-sm border-b-2 transition"
        :class="{
          'border-green-600 text-green-600': activeTab === 'tilt',
          'border-transparent text-gray-600 hover:text-green-600': activeTab !== 'tilt'
        }"
        @click="activeTab = 'tilt'"
      >
        Tilt (°)
      </button>
    </div>

    <!-- Canvas -->
    <div class="relative w-full h-72">
      <canvas ref="canvas" class="w-full h-full"></canvas>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref, watch, nextTick } from 'vue'
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  Title,
  CategoryScale,
  Tooltip,
  Legend
} from 'chart.js'

Chart.register(LineController, LineElement, PointElement, LinearScale, Title, CategoryScale, Tooltip, Legend)

const props = defineProps({
  labels: Array,
  heightValues: Array,
  tiltValues: Array
})

const activeTab = ref('height')
const canvas = ref(null)
let chartInstance = null

const renderChart = () => {
  if (!canvas.value) return
  if (chartInstance) {
    chartInstance.destroy()
  }

  const isHeight = activeTab.value === 'height'
  chartInstance = new Chart(canvas.value, {
    type: 'line',
    data: {
      labels: props.labels,
      datasets: [
        {
          label: isHeight ? 'Height (cm)' : 'Tilt (°)',
          data: isHeight ? props.heightValues : props.tiltValues,
          borderColor: isHeight ? '#3B82F6' : '#38a169',
          backgroundColor: isHeight
            ? 'rgba(59, 130, 246, 0.1)'
            : 'rgba(56, 161, 105, 0.1)',
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        title: { display: false },
        tooltip: { mode: 'index', intersect: false }
      }
    }
  })
}

onMounted(() => {
  renderChart()
})

watch([() => props.labels, () => props.heightValues, () => props.tiltValues, activeTab], async () => {
  await nextTick()
  renderChart()
})
</script>
