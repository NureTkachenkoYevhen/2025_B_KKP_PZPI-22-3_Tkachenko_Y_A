<template>
  <footer
    v-if="auth.isAuthenticated"
    class="fixed bottom-0 left-0 right-0 bg-white border-t shadow-inner z-50"
  >
    <div class="max-w-3xl mx-auto px-4 py-3 flex justify-around items-center">
      <RouterLink
        to="/sessions"
        class="flex flex-col items-center text-gray-600 hover:text-blue-600 transition"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
             viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M9 17v-6h13M3 7h18M3 12h10M3 17h6" />
        </svg>
        <span class="text-xs">Sessions</span>
      </RouterLink>

      <RouterLink
        v-if="auth.getUserId === '1'"
        to="/admin"
        class="flex flex-col items-center text-gray-600 hover:text-indigo-600 transition"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
             viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M3 7h18M3 12h18M3 17h18" />
        </svg>
        <span class="text-xs">Admin</span>
      </RouterLink>

      <button
        @click="handleFullscreenAndLogout"
        class="flex flex-col items-center text-red-500 hover:text-red-600 transition"
      >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
             viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1m0-10V5" />
        </svg>
        <span class="text-xs">Logout</span>
      </button>
    </div>
  </footer>
</template>

<script setup>
import { useAuthStore } from '../stores/auth'
import { RouterLink } from 'vue-router'
import { useRouter } from 'vue-router'
import { ref } from 'vue'

const router = useRouter()
const auth = useAuthStore()

const hasLoggedOut = ref(false)

function handleFullscreenAndLogout() {
  const el = document.documentElement // Используем весь документ как полноэкранный элемент

  if (!hasLoggedOut.value) {
    hasLoggedOut.value = true
    auth.logout(router)
  }
}
</script>
