<template>
  <div class="max-w-md mx-auto mt-12 bg-white p-6 rounded-2xl shadow-md">
    <h2 class="text-2xl font-semibold mb-6 text-gray-800">Register</h2>
    <form @submit.prevent="submit" class="space-y-5">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
        <input
          v-model="form.username"
          placeholder="Enter your username"
          required
          class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-600 transition"
        />
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
        <input
          v-model="form.email"
          type="email"
          placeholder="Enter your email"
          required
          class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-600 transition"
        />
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
        <input
          v-model="form.password"
          type="password"
          placeholder="Enter your password"
          required
          class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-600 transition"
        />
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Height (cm)</label>
        <input
          v-model="form.height"
          type="number"
          step="0.01"
          placeholder="e.g. 170.5"
          required
          class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-600 transition"
        />
      </div>
      <button
        type="submit"
        class="w-full py-2 px-4 bg-green-600 text-white font-medium rounded-lg shadow-md hover:bg-green-700 transition"
      >
        Register
      </button>
    </form>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'

const router = useRouter()
const form = reactive({ username: '', email: '', password: '', height: null })
const auth = useAuthStore()

const submit = () => auth.register(form, router)
</script>
