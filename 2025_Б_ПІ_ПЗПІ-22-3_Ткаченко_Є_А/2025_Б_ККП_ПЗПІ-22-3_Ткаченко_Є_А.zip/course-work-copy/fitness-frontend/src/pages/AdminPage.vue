<template>
  <div class="max-w-4xl mx-auto mt-10 p-4">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Користувачі</h2>

    <div class="space-y-6">
      <div
        v-for="user in users.items"
        :key="user.userId"
        class="bg-white rounded-xl shadow-md p-4 border border-gray-100"
      >
        <table class="w-full text-sm text-gray-700">
          <tbody class="divide-y divide-gray-200">
            <tr>
              <td class="font-medium w-1/3 py-2">ID</td>
              <td class="py-2">{{ user.userId }}</td>
            </tr>
            <tr>
              <td class="font-medium py-2">Ім’я</td>
              <td class="py-2">{{ user.username }}</td>
            </tr>
            <tr>
              <td class="font-medium py-2">Email</td>
              <td class="py-2">{{ user.email }}</td>
            </tr>
            <tr>
              <td class="font-medium py-2">Зріст</td>
              <td class="py-2">{{ user.height }} см</td>
            </tr>
            <tr>
              <td class="font-medium py-2">Дії</td>
              <td class="py-2">
                <button
                  class="text-sm text-red-600 hover:text-red-700 hover:underline disabled:text-gray-400 disabled:cursor-not-allowed transition"
                  @click="deleteUser(user.userId)"
                  :disabled="user.userId === 1"
                >
                  Видалити
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useUsersStore } from '../stores/users'
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'

const auth = useAuthStore()
const router = useRouter()

if (auth.getUserId !== '1') {
  router.push('/sessions')
}

const users = useUsersStore()
onMounted(users.fetchAll)

const deleteUser = async (id) => {
    await users.deleteUser(id)
}
</script>