<template>
  <div class="max-w-4xl mx-auto mt-10 p-4">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Sessions</h2>

    <div class="mb-6">
      <button
        @click="handleFullscreenAndAddSession"
        class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow-md transition"
      >
        + New Session
      </button>
    </div>

    <ul class="space-y-4">
      <li
        v-for="s in sessions.items"
        :key="s.sessionId"
        class="bg-white p-5 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition"
      >
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

          <div class="flex gap-4 text-sm font-medium">
            <RouterLink
              :to="`/metrics/${s.sessionId}`"
              class="text-blue-600 hover:underline transition"
            >
              Metrics
            </RouterLink>
            <RouterLink
              :to="`/recommendations/${s.sessionId}`"
              class="text-green-600 hover:underline transition"
            >
              Recommendations
            </RouterLink>
          </div>

          <div class="text-sm text-gray-600">
            {{ new Date(s.endTime).toLocaleString() }}
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useSessionsStore } from '../stores/sessions'

const sessions = useSessionsStore()
const sessionCreated = ref(false)

onMounted(sessions.fetch)

function handleFullscreenAndAddSession() {
  const el = document.documentElement


  if (!sessionCreated.value) {
    sessionCreated.value = true
    sessions.create()
  }
}
</script>
