package com.tkachenko.yevhen.workout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
